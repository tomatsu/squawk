package org.sunspotworld;

import java.util.Enumeration;
import com.sun.squawk.Isolate;

class TestIsolate {

//   private static ITriColorLED [] leds = EDemoBoard.getInstance().getLEDs();
    public TestIsolate() {
    }

    public static void main(String[] args) {
        try {
            if (args[0] != null) {
                System.out.println("Isolate: " + args[0]);
            }
            
            Enumeration e = Isolate.currentIsolate().getProperties();
            System.out.println("Isolate Properties:");
            while (e.hasMoreElements()) {
                String key = (String)e.nextElement();
                System.out.println("Property " + key + "=" + Isolate.currentIsolate().getProperty(key));
            }
             
             Runtime.getRuntime().gc();
            System.out.println("RAM free after isolate start: " + Runtime.getRuntime().freeMemory());
//         leds[1].setOff();
//         leds[1].setColor(LEDColor.BLUE);
//         leds[1].setOn();
            Thread.sleep(500);
        //Utils.sleep(500);
//         leds[1].setOff();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
